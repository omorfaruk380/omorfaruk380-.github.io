function convert() {
    let usd = document.getElementById("usd").value;
    let rate = 110; // 1 USD = 110 BDT
    let bdt = usd * rate;
    document.getElementById("result").innerText = usd + " USD = " + bdt + " BDT";
}
